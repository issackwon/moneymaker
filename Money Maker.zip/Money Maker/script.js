// Function to initialize bank value
function initializeBankValue() {
    const bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    const bank = document.getElementById("bank");
    bank.textContent = bank_val;
}

// Function to update bank value
function updateBankValue(delta) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    bank_val += delta;
    const bank = document.getElementById("bank");
    bank.textContent = bank_val;
    localStorage.setItem("bank_val", bank_val);
}

// Initialize bank value on window load
window.onload = function () {
    console.log("window loaded");
    initializeBankValue();
    cursorcount(1);
};

// Function to increment the bank value
function count() {
    updateBankValue(1);
}

// Function to handle cursor count
function cursorcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let cursorcount = parseInt(localStorage.getItem("cursorCountNum")) || 0;
    let cursormoney = 15 * Math.pow(1.15, cursorcount);
    cursormoney = Math.round(cursormoney);
    localStorage.setItem("cursorMoney", cursormoney);

    if (a != 1 && cursormoney <= bank_val) {
        cursorcount++;
        bank_val -= cursormoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for cursormoney
        const cursormoneyText = document.getElementById("cursorMoney");
        cursormoneyText.textContent = cursormoney;
    }

    // Update DOM for cursorcount and cursorMoney
    document.getElementById("cursorCountNum").textContent = cursorcount;
    localStorage.setItem("cursorCountNum", cursorcount);
    document.getElementById("cursorMoney").textContent = cursormoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function grandmacount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let grandmacount = parseInt(localStorage.getItem("grandmaCountNum")) || 0;
    let grandmamoney = 100 * Math.pow(1.15, grandmacount);
    grandmamoney = Math.round(grandmamoney);
    localStorage.setItem("grandmaMoney", grandmamoney);

    if (a != 1 && grandmamoney <= bank_val) {
        grandmacount++;
        bank_val -= grandmamoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for grandmamoney
        const grandmamoneyText = document.getElementById("grandmaMoney");
        grandmamoneyText.textContent = grandmamoney;
    }

    // Update DOM for grandmacount and grandmaMoney
    document.getElementById("grandmaCountNum").textContent = grandmacount;
    localStorage.setItem("grandmaCountNum", grandmacount);
    document.getElementById("grandmaMoney").textContent = grandmamoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

function farmcount(a) {
    let bank_val = parseInt(localStorage.getItem("bank_val")) || 0;
    let farmcount = parseInt(localStorage.getItem("farmCountNum")) || 0;
    let farmmoney = 1100 * Math.pow(1.15, farmcount);
    farmmoney = Math.round(farmmoney);
    localStorage.setItem("farmMoney", farmmoney);

    if (a != 1 && farmmoney <= bank_val) {
        farmcount++;
        bank_val -= farmmoney;
        localStorage.setItem("bank_val", bank_val);

        // Update DOM for farmmoney
        const farmmoneyText = document.getElementById("farmMoney");
        farmmoneyText.textContent = farmmoney;
    }

    // Update DOM for farmcount and farmMoney
    document.getElementById("farmCountNum").textContent = farmcount;
    localStorage.setItem("farmCountNum", farmcount);
    document.getElementById("farmMoney").textContent = farmmoney;

    // Update realCps (if needed)
    let realCps = 0;
    localStorage.setItem("realCps", realCps);
}

